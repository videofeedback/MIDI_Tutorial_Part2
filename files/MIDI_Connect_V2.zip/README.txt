

INSTRUCTIONS:

https://github.com/videofeedback/MIDI_Tutorial_Part2/blob/main/README.md


Midi_Tutorial_Part2
MIDI Blueprint for Camera Control

This is the repository for the Midi Tutorial (Part 2) Blueprint.
V2 FIXES:

Added "Default Values" seaparated from the active Float Values so both settings never mix each other.
Added Focus and Focal Length Default Values
Added Channel 2 Sun Macros (Latitude, Azimuth, Intensity)
Note: If you want to collaborate with changes, please fork this repo and let us know about the changes. Thanks.

Instructions
1) Create an Unreal Engine 4.27.1 "Virtual Production" project from templates.
2) Activate the MIDI plugin, and close Unreal Engine
3) Download the ZIP file of this Blueprint MIDI_CONNECT.ZIP
4) Unzip the content of this file into the "Content" folder of your project.
5) Re-Start the project
6) Place the Blueprint "MIDI_CONNECT_V2" Inside the project.